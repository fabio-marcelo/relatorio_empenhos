# ===========================================================================
# CONFIGURAÇÃO DE AMBIENTE E PACOTES (TOTALMENTE AUTOSUFICIENTE)
# ===========================================================================
cat("Verificando e instalando pacotes necessarios. Por favor, aguarde...\n")

# Tente forçar o uso de HTTPS
options(repos = c(CRAN = "https://cloud.r-project.org/"))

# --- Configuração de Ambiente para evitar erros de permissão ---
meu_diretorio_de_pacotes <- file.path(Sys.getenv("USERPROFILE"), "R_packages")
if (!dir.exists(meu_diretorio_de_pacotes)) dir.create(meu_diretorio_de_pacotes)

# Garante que o R use essa pasta para salvar os pacotes
.libPaths(c(meu_diretorio_de_pacotes, .libPaths()))

# PANDOC E RMARKDOWN FORAM REMOVIDOS. Usando comunicação direta com LaTeX!
requiredPackages = c("dplyr","tidyr", "knitr", "readr", "stringr", 
                     "janitor", "tinytex", "kableExtra")   

# Função silenciosa para verificar e instalar pacotes
for(p in requiredPackages){
  if(!require(p, character.only = TRUE, quietly = TRUE)) {
    cat(paste("Instalando pacote:", p, "\n"))
    install.packages(p, dependencies = TRUE, repos = "http://cran.us.r-project.org")
    library(p, character.only = TRUE, quietly = TRUE)
  }
}

# ===========================================================================
# VERIFICAÇÃO INTELIGENTE DO LATEX
# ===========================================================================
# Verifica se já existe pdflatex (ex: MiKTeX) no sistema ou se o TinyTeX já está instalado
tem_latex <- nzchar(Sys.which("pdflatex"))
tem_tinytex <- tinytex::is_tinytex()

if (tem_latex || tem_tinytex) {
  cat("Motor de PDF (LaTeX/MiKTeX) detectado no sistema! Pronto para gerar PDFs diretos.\n")
} else {
  cat("\n==================================================================\n")
  cat("ATENCAO: O motor de PDF nao foi encontrado neste computador.\n")
  cat("Baixando e instalando o TinyTeX. Isso pode demorar alguns minutos...\n")
  cat("==================================================================\n\n")
  
  install.packages("tinytex", repos = "http://cran.us.r-project.org")
  
  tryCatch({
    tinytex::install_tinytex(force = TRUE)
  }, error = function(e) {
    cat("\nAviso: Ocorreu um erro no servidor do TinyTeX (", e$message, ").\n")
  })
}

# Função para proteger caracteres especiais no cabeçalho do LaTeX
escape_latex <- function(x) {
  if (is.na(x) || length(x) == 0) return("")
  x <- gsub("\\\\", "\\\\textbackslash ", x)
  x <- gsub("&", "\\\\&", x)
  x <- gsub("%", "\\\\%", x)
  x <- gsub("\\$", "\\\\$", x)
  x <- gsub("#", "\\\\#", x)
  x <- gsub("_", "\\\\_", x)
  x <- gsub("\\{", "\\\\{", x)
  x <- gsub("\\}", "\\\\}", x)
  x <- gsub("~", "\\\\textasciitilde ", x)
  x <- gsub("\\^", "\\\\textasciicircum ", x)
  return(x)
}

# ===========================================================================
# PASSO 1: SELEÇÃO INTERATIVA DO ARQUIVO CSV
# ===========================================================================
cat("\n==================================================================\n")
cat("ATENCAO: A janela para escolher o arquivo CSV vai abrir agora.\n")
cat("Se nao aparecer na tela, OLHE PARA A BARRA DE TAREFAS (pode estar piscando)!\n")
cat("==================================================================\n")

# Abre uma janela nativa do SO para o usuário escolher o arquivo
arquivo_entrada <- tryCatch({
  if (.Platform$OS.type == "windows") {
    res <- utils::choose.files(caption = "Selecione a planilha CSV do Empenho", multi = FALSE)
    if (length(res) == 0) stop("Cancelado")
    res
  } else {
    file.choose()
  }
}, error = function(e) {
  cat("\nSelecao de arquivo cancelada pelo usuario. Encerrando o programa.\n")
  Sys.sleep(3)
  quit(save = "no")
})

cat("\nArquivo selecionado:", arquivo_entrada, "\n\n")
cat("Iniciando processamento dos dados...\n")

# ===========================================================================
# PASSO 2 A 5: LEITURA E TRATAMENTO DOS DADOS
# ===========================================================================

dados_brutos <- read.csv(arquivo_entrada, sep = ";", header = FALSE, stringsAsFactors = FALSE, encoding = "latin1")
cabecalho_real <- as.character(dados_brutos[10, ])
cabecalho_limpo <- gsub("\\s+", " ", gsub("[\r\n]", " ", cabecalho_real))

colnames(dados_brutos) <- cabecalho_limpo
dados_brutos <- dados_brutos[11:nrow(dados_brutos), ] 

dados_brutos <- dados_brutos %>% 
  dplyr::select(-matches("^NA(\\.\\d+)?$"))

dados_filtrados <- dados_brutos %>%
  filter(
    !is.na(CNPJ) & trimws(CNPJ) != "",
    is.na(`Processo de pagamento e/ou Processo de sanção`) | trimws(`Processo de pagamento e/ou Processo de sanção`) == ""
  )

dados_filtrados <- dados_filtrados[!is.na(dados_filtrados[["Unidade solicitante"]]), ]

# ===========================================================================
# PASSO 6: CRIAÇÃO DA COLUNA UASG E RELATÓRIOS POR GRUPO
# ===========================================================================

dados_filtrados <- dados_filtrados %>%
  mutate(UASG = case_when(
    str_detect(Pregão, "RS") ~ "130103",
    str_detect(Pregão, "PA") ~ "130017",
    str_detect(Pregão, "GO") ~ "130032",
    str_detect(Pregão, "MG") ~ "130058",
    str_detect(Pregão, "PE") ~ "130016",
    str_detect(Pregão, "SP") ~ "130102",
    TRUE ~ NA_character_
  ))

pasta_saida <- "Relatorios_PDF"
if(!dir.exists(pasta_saida)){
  dir.create(pasta_saida)
}

grupos <- dados_filtrados %>%
  distinct(CNPJ, Fornecedor, `Nº Ata`, `N° SEI Ata`, Pregão, UASG)

cat("Foram encontrados", nrow(grupos), "grupos distintos para gerar relatorios.\n")
cat("Gerando PDFs Diretamente em LaTeX, aguarde...\n\n")

# ===========================================================================
# LOOP PARA CADA GRUPO (AGORA EM LATEX PURO!)
# ===========================================================================

for(i in seq_len(nrow(grupos))){
  
  grupo <- grupos[i,]
  
  dados_grupo <- dados_filtrados %>%
    filter(
      CNPJ == grupo$CNPJ,
      `Nº Ata` == grupo$`Nº Ata`,
      `N° SEI Ata` == grupo$`N° SEI Ata`,
      Pregão == grupo$Pregão,
      UASG == grupo$UASG
    )
  
  identificador <- paste(
    gsub("[^0-9]", "", grupo$CNPJ),
    gsub("[^0-9]", "", grupo$`Nº Ata`),
    grupo$UASG,
    sep="_"
  )
  
  arquivo_tex <- file.path(pasta_saida, paste0("temp_", identificador, ".tex"))
  arquivo_pdf <- file.path(pasta_saida, paste0("Relatorio_", identificador, ".pdf"))
  
  cat(sprintf("[%d/%d] Gerando: Relatorio_%s.pdf\n", i, nrow(grupos), identificador))
  
  # -------------------------------------------------------------------------
  # Tabela dos itens
  # -------------------------------------------------------------------------
  
  itens <- dados_grupo %>%
    select(
      Item,
      Código = `Código (Catmat)`,
      `Descrição conforme TR` = `Descrição conforme Termo de Referência (anexo do edital da licitação)`,
      `Unid. Solicitante` = `Unidade solicitante`,
      `Unid. Fornecimento` = `Unidade de fornecimento`,
      `Nat. Despesa` = `Natureza de despesa`,
      Quantidade = `Quantidade solicitada`,
      `Valor unitário (R$)`,
      `Valor total do item (R$)`
    ) %>%
    mutate(across(where(is.character), ~gsub("[\r\n]", " ", .)))
  
  valores <- itens$`Valor total do item (R$)` %>%
    str_replace_all("R\\$", "") %>%
    str_replace_all("\\.", "") %>%
    str_replace_all(",", ".") %>%
    trimws() %>%
    as.numeric()
  
  total <- sum(valores, na.rm = TRUE)
  total_formatado <- paste0("R$ ", format(total, big.mark=".", decimal.mark=",", nsmall=2))
  
  linha_total <- data.frame(
    Item="TOTAL", Código="", `Descrição conforme TR`="",
    `Unid. Solicitante`="", `Unid. Fornecimento`="", `Nat. Despesa`="",
    Quantidade="", `Valor unitário (R$)`="",
    `Valor total do item (R$)`=total_formatado,
    check.names=FALSE
  )
  
  tabela_final <- rbind(itens, linha_total)
  nlinhas <- nrow(tabela_final)
  
  tabela <- kable(
    tabela_final, format="latex", booktabs=TRUE, longtable=TRUE, escape=TRUE
  ) %>%
    kable_styling(latex_options=c("striped", "repeat_header"), font_size=8) %>%
    column_spec(1,width="1cm") %>% column_spec(2,width="1.5cm") %>%
    column_spec(3,width="7cm") %>% column_spec(4,width="2cm") %>%
    column_spec(5,width="2cm") %>% column_spec(6,width="2cm") %>%
    column_spec(7,width="1.5cm") %>% column_spec(8,width="2cm") %>%
    column_spec(9,width="2cm") %>% row_spec(nlinhas, bold=TRUE, background="#e6e6e6")
  
  # -------------------------------------------------------------------------
  # Criação do Arquivo LaTeX Puro
  # -------------------------------------------------------------------------
  
  tex_content <- c(
    "\\documentclass{article}",
    "\\usepackage[landscape, left=1cm, right=1cm, top=1.5cm, bottom=1.5cm]{geometry}",
    "\\usepackage{booktabs}", "\\usepackage{longtable}", "\\usepackage{array}",
    "\\usepackage[table]{xcolor}", 
    "\\usepackage[utf8]{inputenc}", "\\usepackage[T1]{fontenc}",
    "\\usepackage{helvet}", "\\renewcommand{\\familydefault}{\\sfdefault}",
    "\\begin{document}\n",
    "{\\Large \\textbf{SOLICITACAO DE EMPENHO}} \\\\\n",
    paste("\\noindent\\textbf{Fornecedor:} ", escape_latex(grupo$Fornecedor), "\\\\"),
    paste("\\textbf{CNPJ:} ", escape_latex(grupo$CNPJ), "\\\\"),
    paste("\\textbf{Ata de Registro de Precos:} ", escape_latex(grupo$`Nº Ata`), "\\\\"),
    paste("\\textbf{SEI da Ata:} ", escape_latex(grupo$`N° SEI Ata`), "\\\\"),
    paste("\\textbf{Pregao nº:} ", escape_latex(grupo$Pregão), "\\\\"),
    paste("\\textbf{UASG:} ", escape_latex(grupo$UASG), "\\\\[1em]\n"),
    "\\noindent\\rule{\\textwidth}{0.4pt} \\\\[1em]\n"
  )
  
  # Escreve o documento inteiro no ficheiro temporario
  writeLines(c(tex_content, as.character(tabela), "\\end{document}"), arquivo_tex)
  
  # -------------------------------------------------------------------------
  # Renderização direta via Motor de PDF
  # -------------------------------------------------------------------------
  
  tryCatch({
    # Chama o MiKTeX/TinyTeX diretamente no arquivo .tex
    tinytex::pdflatex(arquivo_tex)
    
    # Move e renomeia o PDF gerado
    pdf_gerado <- sub("\\.tex$", ".pdf", arquivo_tex)
    if(file.exists(pdf_gerado)){
      if(file.exists(arquivo_pdf)) file.remove(arquivo_pdf)
      file.rename(pdf_gerado, arquivo_pdf)
    }
  }, error = function(e) {
    cat("Erro ao gerar PDF para o identificador", identificador, ":\n", e$message, "\n")
  })
  
  # Limpa o arquivo de rascunho .tex
  if(file.exists(arquivo_tex)) file.remove(arquivo_tex)
}

cat("\n==================================================================\n")
cat("PROCESSO CONCLUIDO!\n")
cat("Todos os relatorios foram salvos na pasta 'Relatorios_PDF'.\n")
cat("==================================================================\n")