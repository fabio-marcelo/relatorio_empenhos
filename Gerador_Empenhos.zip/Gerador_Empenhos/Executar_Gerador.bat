@echo off
title Gerador de Relatorios
color 0A

:: MAGICA AQUI: Garante que o terminal esta rodando exatamente na mesma pasta deste arquivo .bat
cd /d "%~dp0"

echo ========================================================
echo Iniciando o Gerador de Relatorios PDF...
echo Procurando a instalacao do R no seu computador...
echo ========================================================
echo.

set "RSCRIPT_PATH="

:: Procura pelo R na pasta padrao de 64-bits
if exist "C:\Program Files\R" (
    for /f "delims=" %%i in ('dir /b /s "C:\Program Files\R\Rscript.exe" 2^>nul') do (
        set "RSCRIPT_PATH=%%i"
        goto :encontrado
    )
)

:: Procura pelo R na pasta padrao de 32-bits (caso o sistema seja mais antigo)
if exist "C:\Program Files (x86)\R" (
    for /f "delims=" %%i in ('dir /b /s "C:\Program Files (x86)\R\Rscript.exe" 2^>nul') do (
        set "RSCRIPT_PATH=%%i"
        goto :encontrado
    )
)

:: Se chegou aqui, nao encontrou o R
goto :nao_encontrado

:encontrado
echo R encontrado com sucesso!
echo Caminho: "%RSCRIPT_PATH%"
echo.
echo Executando o script... 
echo ========================================================
echo ATENCAO: A janela para selecionar o arquivo vai abrir. 
echo Se nao aparecer, OLHE A BARRA DE TAREFAS (pode estar piscando)
echo ========================================================
echo.
"%RSCRIPT_PATH%" gerador.R

:: Verifica se a execucao teve sucesso
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Script finalizado. Abrindo a pasta de relatorios...
    if exist "Relatorios_PDF" (
        explorer "Relatorios_PDF"
    )
) else (
    color 0C
    echo.
    echo ========================================================
    echo O SCRIPT R ENCONTROU UM ERRO E FOI INTERROMPIDO.
    echo Verifique as mensagens acima para detalhes.
    echo ========================================================
)
goto :fim

:nao_encontrado
color 0C
echo ========================================================
echo ERRO CRITICO: O R nao foi encontrado.
echo ========================================================
echo.
echo O computador nao possui a linguagem R instalada, ou ela 
echo foi instalada fora da pasta padrao.
echo.
echo Por favor, instale o R baixando-o neste link:
echo https://cran.r-project.org/bin/windows/base/
echo (Basta abrir o instalador e clicar em "Next" ate o fim)
echo.

:fim
echo.
echo Pressione qualquer tecla para fechar esta janela...
pause >nul